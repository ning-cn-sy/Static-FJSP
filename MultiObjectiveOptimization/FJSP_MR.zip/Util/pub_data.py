# -*- coding: utf-8 -*-
# @Time    : 2024/6/26 21:01
# @Author  : 宁诗铎
# @Site    : 
# @File    : pub_data.py
# @Software: PyCharm 
# @Comment : 公共数据

infinity = 9999999
W = 99999.0
