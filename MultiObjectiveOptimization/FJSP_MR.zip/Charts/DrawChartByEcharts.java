package util;

import config.Machine;
import config.Procedure;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;


/**
 * 作图函数测试（ECharts）
 * 作者：宁诗铎
 */
public class DrawChartByEcharts {

    private String CONTENT_STRING = "";
    private HashMap<Integer, Machine> machineMap = new HashMap<>();
    private HashMap<Integer, ArrayList<Procedure>> produreByPiece = new HashMap<>();

    private ArrayList<Procedure> procedureList = new ArrayList<>();
    HashMap<Integer, Integer> procedureIntegerHashMap = new HashMap<>();
    HashMap<Integer, Integer> machineIntegerHashMap = new HashMap<>();

    /**
     * 获取到web文件中的String值
     */
    private void getWebString() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("web/web-ning.html"));//换成你的文件名
            String line;
            while ((line = reader.readLine()) != null) {
                CONTENT_STRING += line;
                CONTENT_STRING += "\n";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 准备所有机器地数据
     */
    private void replaceCategories() {

        List<Machine> machineList = new ArrayList<>();
        machineMap.forEach((integer, machine) -> machineList.add(machine));

        String categoristr = "";
        categoristr += "'" + machineList.get(0).getName() + "'";
        for (int i = 1; i < machineList.size(); i++) {
            categoristr += ",'" + machineList.get(i).getName() + "'";
            machineIntegerHashMap.put(machineList.get(i).id, i);
        }
        //替换类别

        String title = "NSD_CATEGORIES";
        replaceStr(title, CONTENT_STRING.indexOf(title), categoristr);
    }

    /**
     * 准备所有得类型
     */
    private void replaceTypes() {

        List<Integer> tempProcedureList = new ArrayList<>();
        produreByPiece.forEach((integer, procedures) -> tempProcedureList.add(integer));
        String typestr = "";

        typestr += "{name: '" + "工件" + tempProcedureList.get(0) + "', color: colours[0]}";
        procedureIntegerHashMap.put(tempProcedureList.get(0), 0);
        for (int i = 1; i < tempProcedureList.size(); i++) {
            typestr += ",\n{name:'" + "工件" + tempProcedureList.get(i) + "',color:colours[" + i + "]}";
            procedureIntegerHashMap.put(tempProcedureList.get(i), i);
        }

        String title = "NSD_TYPES";
        replaceStr(title, CONTENT_STRING.indexOf(title), typestr);
    }

    /**
     * 替换str
     *
     * @param title
     * @param findindex
     * @param str
     */
    private void replaceStr(String title, int findindex, String str) {
        findindex = CONTENT_STRING.indexOf(title);
        if (findindex >= 0) {
            CONTENT_STRING = CONTENT_STRING.substring(0, findindex) + str
                    + CONTENT_STRING.substring(findindex + title.length());
        }
    }

    /**
     * 准备数据
     */
    private void replaceData() {
        //准备绘图数据
        String alldatastr = "";


        for (int i = 0; i < this.procedureList.size(); i++) {

            Double baseTime = procedureList.get(i).getStartTime();
            Double duration = procedureList.get(i).getProcesstime();
            Integer pieceNum = Integer.valueOf(procedureList.get(i).getId().split("_")[0]);
            alldatastr += "\nbaseTime = " + baseTime + ";\n" +
                    "duration = " + duration + ";\n" +
                    "typeItem = types[" + procedureIntegerHashMap.get(pieceNum) + "];\n" +
                    "data.push({\n" +
                    "            name: typeItem.name,\n" +
                    "            value: [\n" +
                    "                " + machineIntegerHashMap.get(procedureList.get(i).getMachine().id) + ",\n" +
                    "                baseTime,\n" +
                    "                baseTime += duration,\n" +
                    "                duration,\n" +
                    "               '" + procedureList.get(i).getId().replace("_", ",") + "'\n" +
                    "            ],\n" +
                    "            itemStyle: {\n" +
                    "                normal: {\n" +
                    "                    color: typeItem.color\n" +
                    "                }\n" +
                    "            }\n" +
                    "        });";
        }

        String title = "NSD_DATA";
        replaceStr(title, CONTENT_STRING.indexOf(title), alldatastr);

        String title2 = "maxTime";
        replaceStr(title2, CONTENT_STRING.indexOf(title2), "'" + procedureList.stream().mapToDouble(Procedure::getEndTime).max().getAsDouble() + "'");
    }

    /**
     * 画图函数
     *
     * @param produreByPiece
     * @param machineMap
     */
    public void drawEcharts(HashMap<Integer, ArrayList<Procedure>> produreByPiece, HashMap<Integer, Machine> machineMap, ArrayList<Procedure> procedureList, String name) {
        this.produreByPiece = produreByPiece;
        this.machineMap = machineMap;
        this.procedureList = procedureList;

        getWebString();

        replaceCategories();

        replaceTypes();

        replaceData();

        try {
            OutputStreamWriter outweb02 = new OutputStreamWriter(new FileOutputStream("web/" + name +"_"+ procedureList.stream().mapToDouble(Procedure::getEndTime).max().getAsDouble() + ".html"), "UTF-8"); //UTF-8
//            OutputStreamWriter outweb02 = new OutputStreamWriter(new FileOutputStream("web/" + name  + ".html"), "UTF-8"); //UTF-8
            outweb02.write(CONTENT_STRING);
            outweb02.flush();
            outweb02.close();

        } catch (Exception e) {
        }

//        System.out.println("ECharts drawEnd.");

    }
}
